package com.trabalho.Trabalho.LP2.Bruno.record;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Comment {
    private Long id;
    private String content;
}