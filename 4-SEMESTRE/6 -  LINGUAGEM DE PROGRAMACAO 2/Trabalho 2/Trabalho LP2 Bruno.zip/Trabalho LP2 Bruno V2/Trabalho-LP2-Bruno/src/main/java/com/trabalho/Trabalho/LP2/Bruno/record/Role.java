package com.trabalho.Trabalho.LP2.Bruno.record;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class Role {
    private Long id;
    private String name;
}