package com.trabalho.Trabalho.LP2.Bruno.record;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Stock {
    private Long id;
    private Integer quantity;
}