package com.trabalho.Trabalho.LP2.Bruno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoLp2BrunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
