var alcool = prompt('Digite o preço do alcool')

var gasolina = prompt('Digite o preço da gasolina')

var resultado = alcool / gasolina

if (resultado < 0.7) document.write('Abasteça com álcool')
else document.write('Abasteça com gasolina')
