function gerarTabuada() {
    var numero = document.getElementById('numero').value
    var resultado = ''

    for (var i = 1; i <= 10; i++) {
        resultado += numero + ' x ' + i + ' = ' + numero * i + '<br>'
    }

    document.getElementById('resultado').innerHTML = '<p>' + resultado + '</p>'
    document.getElementById('resultado').style.display = 'block'
}
